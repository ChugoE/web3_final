import { useEffect, useState } from "react";
import NavbarComponent from "../../components/NavbarComponent";
import { useNavigate } from "react-router-dom";
import { Pump } from "../../models/objects/Pump";
import { FuelStock } from "../../models/objects/FuelStock";
import { PumpService } from "../../services/api/PumpService";
import { StockService } from "../../services/api/StockService";
import { Sale } from "../../models/objects/Sale";
import { SaleService } from "../../services/api/SaleService";
import { Routes } from "../../routes/CONSTANTS";
import { Button, Input, Menu, MenuHandler, MenuItem, MenuList, Typography } from "@material-tailwind/react";
import { changeInput } from "../../utilities/FormUtils";
import { Client } from "../../models/objects/Client";
import { ClientService } from "../../services/api/ClientService";
import AddClientModal from "../../components/modals/AddClientModal";

const SaleCreatePage = () => {
    const emptyClient = { name: "", last_name: "", email: "", phone: "" };
    const emptyFuelStock = { quantity: 0, station_id: 0, price: 0 };
    const [error, setError] = useState("");
    const [pumps, setPumps] = useState<Pump[]>([]);
    const [stock, setStock] = useState<FuelStock[]>([]);
    const [clients, setClients] = useState<Client[]>([]);
    const [selectedClient, setSelectedClient] = useState<Client>(emptyClient);
    const [selectedStock, setSelectedStock] = useState<FuelStock>(emptyFuelStock);
    const [clientMenuOpen, setClientMenuOpen] = useState(false);
    const [clientModalOpen, setClientModalOpen] = useState(false);
    const stationId = sessionStorage.getItem('userStationId');
    const navigate = useNavigate();

    type Inputs = {
        name: string,
        nit: string,
        client: number,
        quantity: string,
        fuelType: string,
        pump: string
    }

    const [inputs, setInputs] = useState<Inputs>({
        name: "",
        nit: "",
        client: 0,
        quantity: "",
        fuelType: "0",
        pump: "0"
    });

    const validate = (newInputs: Inputs): Errors => {
        const newErrors: Errors = {}
        if (!newInputs.name) newErrors.name = true
        if (!newInputs.nit) newErrors.nit = true
        if (newInputs.client === 0) newErrors.client = true
        if (!newInputs.quantity) newErrors.quantity = true
        if (newInputs.fuelType === "0") newErrors.fuelType = true
        if (newInputs.pump === "0") newErrors.pump = true

        if (newInputs.quantity && newInputs.fuelType !== "0") {
            if (!selectedStock.id) {
                newErrors.fuelType = true;
                setError('No hay Stock disponible para realizar la venta');
            } else if (Number(newInputs.quantity) > selectedStock.quantity) {
                newErrors.quantity = true;
                setError('No hay suficiente stock para realizar la venta');
            }
        }

        return newErrors
    }

    type Errors = Partial<Record<keyof Inputs, boolean>>
    const [errors, setErrors] = useState<Errors>({});

    useEffect(() => {
        fetchPumps();
        fetchStock();
        fetchClients();
    }, []);

    useEffect(() => {
        if (inputs.fuelType === "0") {
            setSelectedStock(emptyFuelStock);
            return;
        }
        const selectedStock = stock.find(stock => stock.fuel_type?.id === Number(inputs.fuelType));
        setSelectedStock(selectedStock || emptyFuelStock);
    }, [inputs.fuelType]);

    const fetchPumps = () => {
        PumpService.getByStation(Number(stationId)).then(response => setPumps(response));
    }

    const fetchStock = () => {
        StockService.getByStation(Number(stationId)).then(response => setStock(response));
    }

    const fetchClients = () => {
        ClientService.list().then(response => setClients(response));
    }

    const onFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setError('');
        const validatedErrors = validate(inputs);
        setErrors(validatedErrors);
        const isValid = Object.keys(validatedErrors).length === 0;

        if (!isValid) {
            return;
        }
        createSale();
    }

    const createSale = () => {
        const newSale: Sale = {
            sale_name: inputs.name,
            client_id: inputs.client,
            fuel_quantity: Number(inputs.quantity),
            nit: Number(inputs.nit),
            fuel_type_id: Number(inputs.fuelType),
            pump_id: Number(inputs.pump)
        };
        SaleService.create(newSale)
            .then(() => navigate(Routes.SALE.LIST))
            .catch(() => setError('Error al realizar la venta'));
    }

    const getClientForDisplay = (client: Client) => {
        return client.name + " " + client.last_name;
    }

    const handleClientChange = (client: Client) => {
        setSelectedClient(client);
        setInputs({ ...inputs, client: client.id! });
        setErrors({ ...errors, client: false });
        setClientMenuOpen(false);
    }

    return (
        <>
            <NavbarComponent />
            <main className="flex flex-col items-center mb-5">
                <h1 className="text-3xl font-bold py-5" style={{ color: 'black' }}>Realizar Venta</h1>
                <form className="w-[800px] bg-white p-3 rounded-md border border-gray-300 flex justify-around" onSubmit={(e) => onFormSubmit(e)}>
                    <div>
                        <Input className="focus:border-cyan-600 focus:border-t-transparent peer-focus:before:!border-cyan-600 mb-3" name="name"
                            value={inputs.name} onChange={(e) => changeInput(e, setInputs, setErrors)}
                            type="text" crossOrigin={null} error={errors.name} label="Nombre de Factura"
                            labelProps={{
                                className: "peer-focus:before:!border-cyan-600 peer-focus:after:!border-cyan-600 peer-focus:text-cyan-600",
                                style: { color: 'black', fontWeight: 'bold' }
                            }}
                            containerProps={{ className: "mb-3" }}
                            style={{ color: 'black', fontWeight: 'bold' }} />
                        <Input className="focus:border-cyan-600 focus:border-t-transparent peer-focus:before:!border-cyan-600 mb-3" name="nit"
                            value={inputs.nit} onChange={(e) => changeInput(e, setInputs, setErrors)}
                            type="number" crossOrigin={null} error={errors.nit} label="Nit"
                            labelProps={{
                                className: "peer-focus:before:!border-cyan-600 peer-focus:after:!border-cyan-600 peer-focus:text-cyan-600",
                                style: { color: 'black', fontWeight: 'bold' }
                            }}
                            containerProps={{ className: "mb-3" }}
                            style={{ color: 'black', fontWeight: 'bold' }} />
                        <Input className="focus:border-cyan-600 focus:border-t-transparent peer-focus:before:!border-cyan-600 mb-3" name="quantity"
                            value={inputs.quantity} onChange={(e) => changeInput(e, setInputs, setErrors)}
                            type="number" crossOrigin={null} error={errors.quantity} label="Cantidad de Combustible"
                            labelProps={{
                                className: "peer-focus:before:!border-cyan-600 peer-focus:after:!border-cyan-600 peer-focus:text-cyan-600",
                                style: { color: 'black', fontWeight: 'bold' }
                            }}
                            containerProps={{ className: "mb-3" }}
                            style={{ color: 'black', fontWeight: 'bold' }} />
                        <div className="mb-3">
                            <Typography style={{ fontFamily: 'Consolas', color: 'black', fontWeight: 'bold' }}>Bomba</Typography>
                            <select value={inputs.pump} onChange={(e) => changeInput(e, setInputs, setErrors)}
                                className={`w-full p-2.5 bg-white border border-gray-300 rounded-md
                            focus:border-cyan-600 focus:border-2 
                            ${errors.pump ? "border-red-500 text-red-500" : ""}`}
                                name="pump"
                                style={{ fontFamily: 'Consolas', color: 'black', fontWeight: 'bold' }}>
                                <option value={0}>Seleccione una Bomba</option>
                                {pumps.map(pump => (
                                    <option key={pump.id} value={pump.id} className="">
                                        {pump.code}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div className="mb-3">
                            <Typography style={{ fontFamily: 'Consolas', color: 'black', fontWeight: 'bold' }}>Tipo de Combustible</Typography>
                            <select value={inputs.fuelType} onChange={(e) => changeInput(e, setInputs, setErrors)}
                                className={`w-full p-2.5 bg-white border border-gray-300 rounded-md
                            focus:border-cyan-600 focus:border-2 
                            ${errors.fuelType ? "border-red-500 text-red-500" : ""}`}
                                name="fuelType"
                                style={{ fontFamily: 'Consolas', color: 'black', fontWeight: 'bold' }}>
                                {inputs.pump !== "0" ? <option value={0}>Seleccione un Tipo de Combustible</option> :
                                    <option value={0}>Seleccione una Bomba primero</option>}
                                {inputs.pump !== "0" && pumps.find(pump => pump.id + "" === inputs.pump)?.fuel_types?.map(fuel => (
                                    <option key={fuel.id} value={fuel.id} className="">
                                        {fuel.name}
                                    </option>
                                ))}
                            </select>
                        </div>
                    </div>
                    <div>
                        <Menu placement="bottom-start" open={clientMenuOpen} handler={setClientMenuOpen}
                            dismiss={{ itemPress: false }}>
                            <MenuHandler>
                                <p className={`border border-gray-300 p-2 rounded-md text-sm 
                                ${clientMenuOpen ? "border-2 border-cyan-600" : ""} 
                                ${errors.client ? "border-red-500 text-red-500" : ""}
                                ${inputs.client ? "text-gray-800" : "text-gray-400"}`}
                                    style={{ fontFamily: 'Consolas', color: 'black', fontWeight: 'bold' }}>
                                    {inputs.client ? getClientForDisplay(selectedClient) : "Seleccionar Cliente"}
                                </p>
                            </MenuHandler>
                            <MenuList className="max-h-[20rem] max-w-[18rem] bg-white">
                                {clients.map(client => (
                                    <MenuItem key={client.id}
                                        className="flex items-center gap-2 rounded-none border-t"
                                        onClick={() => handleClientChange(client)}
                                        style={{ fontFamily: 'Consolas', color: 'black', fontWeight: 'bold' }}>
                                        <p>{client.name + " " + client.last_name}</p>
                                    </MenuItem>
                                ))}
                            </MenuList>
                        </Menu>
                        <Button size="sm" variant="text" className="w-full bg-cyan-600 text-black py-2.5 rounded-md my-4"
                            ripple={false} onClick={() => setClientModalOpen(true)}
                            style={{ color: 'black', fontWeight: 'bold' }}>
                            Agregar un Nuevo Cliente
                        </Button>
                        <h5 className="font-bold" style={{ color: 'black' }}>Stock Disponible: </h5>
                        <div className="flex justify-between items-center border-b-2 border-cyan-600 py-2 mb-3">
                            {(() => {
                                if (inputs.fuelType === "0") {
                                    return <p className="block" style={{ color: 'black', fontWeight: 'bold' }}>Seleccione un Tipo de Combustible</p>;
                                } else if (!selectedStock?.id) {
                                    return <p className="block" style={{ color: 'black', fontWeight: 'bold' }}>No hay Stock disponible</p>;
                                } else {
                                    return (
                                        <>
                                            <p style={{ color: 'black', fontWeight: 'bold' }}>{selectedStock.fuel_type?.name}</p>
                                            <p style={{ color: 'black', fontWeight: 'bold' }}>{selectedStock.quantity} lt</p>
                                        </>
                                    );
                                }
                            })()}
                        </div>
                        <div className="flex gap-2 mb-3">
                            <h5 className="font-bold" style={{ color: 'black', fontWeight: 'bold' }}>Precio Por Litro: </h5>
                            {selectedStock.id && <p className="text-gray-800">{selectedStock.price} Bs</p>}
                        </div>
                        <div className="flex gap-2">
                            <h5 className="font-bold" style={{ color: 'black', fontWeight: 'bold' }}>Total: </h5>
                            {selectedStock.id && inputs.quantity &&
                                <p className="text-gray-800">{selectedStock.price * Number(inputs.quantity)} Bs</p>}
                        </div>
                        <div className="mb-3 w-full">
                            <p className="block text-md font-medium text-red-600 mb-1">
                                {error}
                            </p>
                            <button type="submit" className="w-full bg-cyan-600 text-black py-2.5 rounded-md"
                                style={{ fontFamily: 'Consolas', fontWeight: 'bold' }}>
                                Guardar
                            </button>
                        </div>
                    </div>
                </form>
            </main>
            <AddClientModal isOpen={clientModalOpen} handleOpen={() => {
                setClientModalOpen(false)
                fetchClients()
            }} />
        </>
    );
}

export default SaleCreatePage;

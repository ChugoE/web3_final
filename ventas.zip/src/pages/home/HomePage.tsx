import { useEffect, useState } from 'react';
import NavbarComponent from '../../components/NavbarComponent'
import { Routes } from '../../routes/CONSTANTS'
import { ROLE_IDS } from '../../utilities/constants';
import { StationService } from '../../services/api/StationService';

function HomePage() {
	const userRole = Number(sessionStorage.getItem('userRole'));
	const [station, setStation] = useState("");

	useEffect(() => {
		fetchStationName();
	}, []);

	const fetchStationName = () => {
		const stationId = sessionStorage.getItem('userStationId');
		if (!stationId) return;
		StationService.get(Number(stationId)).then(response => {
			setStation(response.name);
		}
		).catch((error) => {
			console.log(error);
		});
	}

	return (
		<>
			<NavbarComponent />
			<div className="flex justify-center items-center">
				<div className="bg-gray-900 text-white p-6 rounded-xl shadow-md text-center w-96 mt-48">
					<h1 className="text-3xl font-bold py-5">
						{station ? `Bienvenido a ${station}` : "Bienvenido"}
					</h1>
					{!station && <h5 className='text-xl'>Aún no tienes un surtidor asignado</h5>}
					{station && (
						<div className="flex flex-col gap-5">
							{userRole === ROLE_IDS.SALESPERSON && (
								<a href={Routes.SALE.CREATE}
									className="bg-cyan-600 p-2 text-lg font-bold border-2 border-gray-600 rounded-md flex items-center justify-center">
									<i className="fa-solid fa-cash-register mr-2"></i> Realizar Venta
								</a>
							)}
							{userRole === ROLE_IDS.STATION_MANAGER && (
								<a href={Routes.STATION.MANAGE}
									className="bg-cyan-600 p-2 text-lg font-bold border-2 border-gray-600 rounded-md flex items-center justify-center">
									<i className="fa-solid fa-gas-pump mr-2"></i> Administrar Surtidor
								</a>
							)}
							<a href={Routes.SALE.LIST}
								className="bg-cyan-600 p-2 text-lg font-bold border-2 border-gray-600 rounded-md flex items-center justify-center">
								<i className="fa-solid fa-list mr-2"></i> Registro de Ventas
							</a>
						</div>
					)}
				</div>
			</div>

		</>
	);

}

export default HomePage

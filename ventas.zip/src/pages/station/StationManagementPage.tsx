import { Button } from "@material-tailwind/react";
import { Routes } from "../../routes/CONSTANTS";
import NavbarComponent from "../../components/NavbarComponent";
import { useEffect, useState } from "react";
import { Pump } from "../../models/objects/Pump";
import { PumpService } from "../../services/api/PumpService";
import AssignFuelTypesModal from "../../components/modals/AssignFuelTypesModal";
import { FuelType } from "../../models/objects/FuelType";
import { StationService } from "../../services/api/StationService";

const PumpManagementPage = () => {
    const [pumps, setPumps] = useState<Pump[]>([]);
    const [isAssignModalOpen, setIsAssignModalOpen] = useState<boolean>(false);
    const [stationFuelTypes, setStationFuelTypes] = useState<FuelType[]>([]);
    const stationId = sessionStorage.getItem('userStationId');

    useEffect(() => {
        fetchPumps();
        fetchFuelTypes();
    }, []);

    const fetchPumps = () => {
        if (!stationId) return;
        PumpService.getByStation(Number(stationId)).then(response => {
            setPumps(response);
        });
    }

    const fetchFuelTypes = () => {
        StationService.getFuelTypes(Number(stationId)).then(response => {
            setStationFuelTypes(response);
        });
    }

    const deletePump = (id: number) => {
        PumpService.delete(id).then(() => {
            fetchPumps();
        });
    }

    const onFuelAssign = () => {
        setIsAssignModalOpen(false);
        fetchFuelTypes();
    }

    return (
        <>
            <NavbarComponent />
            <main className="flex flex-col items-center justify-center">
                <h1 className="text-3xl text-white font-bold py-8 text-center">Administrar Surtidor</h1>
                <div className="grid grid-cols-1 gap-3 justify-items-center w-full max-w-3xl">
                    <div className="w-full bg-gray-900 text-white rounded-md p-3 ">
                        <div className="flex items-center justify-between gap-3 text-center border-b-2">
                            <h5 className="text-xl font-bold text-white text-center">Bombas</h5>
                            <a href={Routes.PUMP.CREATE}>
                                <Button type="button" size="sm" className="p-2 bg-blue-600 text-xs mb-4  h-[35px]">
                                    Agregar
                                </Button>
                            </a>
                        </div>
                        <div className="grid grid-cols-4">
                            <div>
                                Código
                            </div>
                            <div>
                                Tipos de combustible
                            </div>
                            <div className="ml-48">
                                Acciones
                            </div>
                        </div>
                        {pumps.map((pump) => (
                            <div key={"pump-" + pump.id} className="grid grid-cols-4  py-2">
                                <p className="font-bold text-cyan-300 col-span-1">{pump.code}</p>
                                <div className="flex flex-wrap col-span-2">
                                    {pump.fuel_types?.map((fuel) => (
                                        <p key={"fuel-" + fuel.id} className="text-xs font-bold p-1.5 m-0 text-gray-300rounded-md">
                                            {fuel.name}
                                        </p>
                                    ))}
                                </div>
                                <div className="flex gap-3 col-span-1">
                                    <a href={Routes.PUMP.EDIT_PARAM(pump.id)}>
                                        <Button type="button" size="sm" className="h-[35px] bg-cyan-600 text-xs text-white">
                                            Editar
                                        </Button>
                                    </a>
                                    <Button type="button" size="sm" className="text-xs bg-red-600 text-white" onClick={() => deletePump(pump.id!)}>
                                        Eliminar
                                    </Button>
                                </div>
                            </div>

                        ))}
                    </div>
                    <div className="w-full bg-gray-900 rounded-md border border-gray-800 p-3 text-white">
                        <div className="flex items-center justify-between gap-3 text-center">
                            <h5 className="text-xl font-bold text-cyan-300 text-center">Tipos de Combustible</h5>
                            <Button
                                type="button"
                                size="sm"
                                className="p-2 bg-blue-600 text-xs mb-4  h-[35px]"
                                onClick={() => setIsAssignModalOpen(true)}>
                                Agregar
                            </Button>
                        </div>
                        {stationFuelTypes.map((fuel) => (
                            <div key={"fuel-" + fuel.id}
                                className="flex justify-between items-center  py-2">
                                <p className="font-bold text-gray-300">{fuel.name}</p>
                            </div>
                        ))}
                    </div>

                </div>
            </main>
            <AssignFuelTypesModal isOpen={isAssignModalOpen} handleOpen={() => onFuelAssign()} />
        </>
    );


}

export default PumpManagementPage;
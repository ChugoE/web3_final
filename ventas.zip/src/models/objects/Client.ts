export interface Client {
    id?: number;
    name: string;
    last_name: string;
    email: string;
    phone: string;
}
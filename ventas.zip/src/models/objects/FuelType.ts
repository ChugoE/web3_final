export interface FuelType{
    id?: number;
    name: string;
}
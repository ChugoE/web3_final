import { Button, Dialog, DialogBody, DialogFooter, DialogHeader, Switch } from "@material-tailwind/react";
import { useEffect, useState } from "react";
import { FuelType } from "../../models/objects/FuelType";
import { FuelTypeService } from "../../services/api/FuelTypeService";
import { StationService } from "../../services/api/StationService";

type Props = {
    isOpen: boolean,
    handleOpen: () => void,
}

const AssignFuelTypesModal = ({ isOpen, handleOpen }: Props) => {
    const [fuelTypes, setFuelTypes] = useState<FuelType[]>([]);
    const [selectedFuelTypes, setSelectedFuelTypes] = useState<number[]>([]);
    const stationId = sessionStorage.getItem('userStationId');

    useEffect(() => {
        fetchFuelTypes();
        fetchStationFuelTypes();
    }, []);

    const fetchFuelTypes = () => {
        FuelTypeService.list().then(response => {
            setFuelTypes(response);
        });
    }

    const fetchStationFuelTypes = () => {
        StationService.getFuelTypes(Number(stationId)).then(response => {
            setSelectedFuelTypes(response.map(f => f.id!));
        }).catch(error => console.log(error));
    }

    const handleFuelTypeChange = (fuelTypeId: number) => {
        if (selectedFuelTypes.includes(fuelTypeId)) {
            setSelectedFuelTypes(selectedFuelTypes.filter(id => id !== fuelTypeId));
        } else {
            setSelectedFuelTypes([...selectedFuelTypes, fuelTypeId]);
        }
    }

    const saveChanges = () => {
        StationService.assignFuelTypes(Number(stationId), selectedFuelTypes)
            .then(() => handleOpen())
            .catch(error => console.log(error));
    }

    return (
        <Dialog open={isOpen} handler={handleOpen} className="bg-white border border-gray-300">
            <DialogHeader className="text-black border-0 border-b border-gray-300 font-bold">Asignar Combustibles</DialogHeader>
            <DialogBody className="text-black font-bold">
                <div className="flex flex-col gap-2">
                    {fuelTypes.map((fuelType) => (
                        <label key={"fuel-type-" + fuelType.id} className="flex items-center">
                            <input
                                type="checkbox"
                                className="form-checkbox h-4 w-4 text-cyan-600"
                                checked={selectedFuelTypes.includes(fuelType.id!)}
                                onChange={() => handleFuelTypeChange(fuelType.id!)}
                            />
                            <span className="ml-2 text-black font-bold">{fuelType.name}</span>
                        </label>
                    ))}
                </div>
            </DialogBody>
            <DialogFooter className="border-0 border-t border-gray-300">
                <Button variant="gradient" color="red" onClick={handleOpen} className="mr-1 text-black">
                    <span>Cancelar</span>
                </Button>
                <Button className="bg-cyan-600 text-black" onClick={() => saveChanges()}>
                    <span>Confirmar</span>
                </Button>
            </DialogFooter>
        </Dialog>


    );

}

export default AssignFuelTypesModal;
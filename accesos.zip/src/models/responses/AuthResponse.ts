export interface AuthResponse {
    refresh: string;
    access:  string;
}
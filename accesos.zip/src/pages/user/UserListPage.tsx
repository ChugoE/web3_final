import { useEffect, useState } from "react";
import { User } from "../../models/objects/User";
import NavbarComponent from "../../components/NavbarComponent";
import { UserService } from "../../services/UserService";
import { Routes } from "../../routes/CONSTANTS";
import { Button } from "@material-tailwind/react";
import { Role } from "../../models/objects/Role";

const UserListPage = () => {
    const [users, setUsers] = useState<User[]>([]);
    const [roles, setRoles] = useState<Role[]>([]);

    useEffect(() => {
        fetchRoles();
        fetchUsers();
    }, []);

    const fetchUsers = () => {
        UserService.list().then(response => {
            setUsers(response);
        });
    }

    const fetchRoles = () => {
        UserService.roleList().then(response => {
            setRoles(response);
        });
    }

    const deleteUser = (id: number) => {
        UserService.delete(id).then(() => {
            fetchUsers();
        });
    }

    const getRoleForDisplay = (role: number) => {
        return roles.find(r => r.id === role)?.name;
    }

    return (
        <>
            <NavbarComponent />
            <main className="px-20">
                <div className="flex justify-between items-center">
                    <h1 className="text-3xl text-black font-bold py-8 w-fit text-nowrap">Administrar Usuarios</h1>
                    <a href={Routes.USER.CREATE}>
                        <Button type="button" size="sm" className="bg-cyan-600 border-2 border-gray-400 text-black">Agregar</Button>
                    </a>
                </div>
                <table className="table-auto w-full border-collapse border border-gray-300 ">
                    <thead>
                        <tr className="border-b-2 border-cyan-600 p-1">
                            <th className="text-lg ps-3 text-left text-black border border-gray-300">Nombre</th>
                            <th className="text-lg ps-3 text-left text-black border border-gray-300">Teléfono</th>
                            <th className="text-lg ps-3 text-left text-black border border-gray-300">Email</th>
                            <th className="text-lg ps-3 text-left text-black border border-gray-300">Rol</th>
                            <th className="text-lg ps-3 text-left text-black border border-gray-300">Surtidor</th>
                            <th className="text-lg ps-3 text-left border border-gray-300"></th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map((user) => (
                            <tr key={"cat-" + user.id} className="border-b border-gray-300 text-black">
                                <td className="ps-3 pt-2 border border-gray-300">{user.first_name + " " + user.last_name}</td>
                                <td className="ps-3 pt-2 border border-gray-300">{user.phone}</td>
                                <td className="ps-3 pt-2 border border-gray-300">{user.username}</td>
                                <td className="ps-3 pt-2 border border-gray-300">{getRoleForDisplay(user.role)}</td>
                                <td className="ps-3 pt-2 border border-gray-300">{user.station?.name}</td>
                                <td className="ps-3 pt-2 border border-gray-300 text-center">
                                    <a href={Routes.USER.EDIT_PARAM(user.id)} className="me-2">
                                        <Button type="button" size="sm" className="bg-cyan-600 border-2 border-gray-400 text-black">
                                            Editar
                                        </Button>
                                    </a>
                                    <Button type="button" size="sm" color="red" className="border-2 border-red-900 text-black"
                                        onClick={() => { deleteUser(user.id!) }}>
                                        Eliminar
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </main>
        </>
    );
}

export default UserListPage;

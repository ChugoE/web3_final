import React, { useEffect, useState } from "react";
import NavbarComponent from "../../components/NavbarComponent";
import { useNavigate, useParams } from "react-router-dom";
import { StationService } from "../../services/StationService";
import { Routes } from "../../routes/CONSTANTS";
import { Station } from "../../models/objects/Station";
import { Input } from "@material-tailwind/react";
import { GoogleMap, Marker, useJsApiLoader } from "@react-google-maps/api";

const StationFormPage = () => {
    const { id } = useParams();
    const [name, setName] = useState("");
    const [latitude, setLatitude] = useState("");
    const [longitude, setLongitude] = useState("");
    const [mapLatitude, setMapLatitude] = useState("");
    const [mapLongitude, setMapLongitude] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const mapsApiKey = "AIzaSyB85G7SW_7cFr0CeSSG0NaCtDTJvHDeuOI";
    const { isLoaded: isLoaded } = useJsApiLoader({
        id: 'google-map-script',
        googleMapsApiKey: mapsApiKey
    });

    const validate = (): boolean => {
        if (name === "") {
            setError('Ingrese un nombre');
            return false;
        } else if (latitude === "" || longitude === "") {
            setError('Seleccione una ubicación');
            return false;
        }
        return true;
    }

    useEffect(() => {
        if (id) fetchStation();
        if (navigator.geolocation) {
            if (id) {
                return;
            }
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setMapLatitude(position.coords.latitude + "");
                    setMapLongitude(position.coords.longitude + "");
                },
                (error) => {
                    console.error(`Error al obtener la ubicación: ${error.message}`);
                }
            );
        } else {
            console.error('La geolocalización no es compatible con este navegador.');
        }
    }, []);

    const fetchStation = () => {
        StationService.get(Number(id)).then(response => {
            setName(response.name);
            setLatitude(response.latitude + "");
            setLongitude(response.longitude + "");
            setMapLatitude(response.latitude + "");
            setMapLongitude(response.longitude + "");
        }).catch((error) => {
            console.log(error);
        });
    }

    const onFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setError('');
        if (!validate()) return;

        if (!id) {
            createStation();
        } else {
            updateStation();
        }
    }

    const createStation = () => {
        const newStation: Station = {
            name: name,
            latitude: Number(latitude),
            longitude: Number(longitude)
        }
        StationService.create(newStation)
            .then(() => navigate(Routes.STATION.LIST))
            .catch(() => setError('Error al crear el surtidor'));
    }

    const updateStation = () => {
        const newStation: Station = {
            id: Number(id),
            name: name,
            latitude: Number(latitude),
            longitude: Number(longitude)
        }
        StationService.update(newStation)
            .then(() => navigate(Routes.STATION.LIST))
            .catch(() => setError('Error al actualizar el surtidor'));
    }

    const handleMapClick = (event: google.maps.MapMouseEvent) => {
        const { latLng } = event;
        const lat = latLng?.lat();
        const lng = latLng?.lng();
        setLatitude(lat + "");
        setLongitude(lng + "");
    };

    return (
        <>
            <NavbarComponent />
            <main className="flex flex-col items-center mb-5">
                <h1 className="text-3xl font-bold py-5" style={{ color: 'black', fontFamily: 'Consolas' }}>
                    {id ? "Editar" : "Crear"} Surtidor
                </h1>
                <form className="w-full bg-white p-3 rounded-md border border-gray-300" onSubmit={(e) => onFormSubmit(e)}>
                    <Input className="text-gray-800 focus:border-cyan-600 focus:border-t-transparent 
                            peer-focus:before:!border-cyan-600 mb-3" name="name"
                        value={name} onChange={(e) => setName(e.target.value)}
                        type="text" crossOrigin={null} label="Nombre"
                        labelProps={{
                            className: "peer-focus:before:!border-cyan-600 " +
                                "peer-focus:after:!border-cyan-600 peer-focus:text-cyan-600",
                        }}
                        containerProps={{ className: "mb-3" }} style={{ color: 'black', fontFamily: 'Consolas', fontWeight: 'bold' }} />
                    {mapLatitude !== "" && isLoaded && <div className="w-full h-[50vh]">
                        <GoogleMap
                            center={{
                                lat: parseFloat(mapLatitude),
                                lng: parseFloat(mapLongitude)
                            }}
                            options={{
                                zoomControl: false,
                                scaleControl: false,
                                streetViewControl: false,
                                mapTypeControl: false,
                            }}
                            zoom={14}
                            onClick={handleMapClick}
                            mapContainerStyle={{ width: '100%', height: '100%' }}
                        >
                            {latitude !== "" &&
                                <Marker position={{ lat: Number(latitude), lng: Number(longitude) }} />}
                        </GoogleMap>
                    </div>}
                    <div className="mb-3">
                        <p className="block text-md font-medium text-red-600 mb-1" style={{ fontFamily: 'Consolas' }}>
                            {error}
                        </p>
                        <button type="submit" className="w-full bg-cyan-600 text-white py-2.5 rounded-md" style={{ fontFamily: 'Consolas', fontWeight: 'bold' }}>
                            Guardar
                        </button>
                    </div>
                </form>
            </main>
        </>
    );

}

export default StationFormPage;

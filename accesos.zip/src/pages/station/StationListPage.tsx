import { Button } from "@material-tailwind/react";
import { Routes } from "../../routes/CONSTANTS";
import NavbarComponent from "../../components/NavbarComponent";
import { useEffect, useState } from "react";
import { Station } from "../../models/objects/Station";
import { StationService } from "../../services/StationService";

const StationListPage = () => {
    const [stations, setStations] = useState<Station[]>([]);

    useEffect(() => {
        fetchStations();
    }, []);

    const fetchStations = () => {
        StationService.list().then(response => {
            setStations(response);
        });
    }

    const deleteStation = (id: number) => {
        StationService.delete(id).then(() => {
            fetchStations();
        });
    }

    return (
        <>
            <NavbarComponent />
            <main className="px-20">
                <div className="flex justify-between items-center">
                    <h1 className="text-3xl font-bold py-8 w-fit text-nowrap" style={{ color: 'black', fontFamily: 'Consolas' }}>
                        Administrar Surtidores
                    </h1>
                    <a href={Routes.STATION.CREATE}>
                        <Button type="button" size="sm" className="bg-cyan-600 border-2 border-gray-400 text-black">
                            Agregar
                        </Button>
                    </a>
                </div>
                <table className="table-auto w-full border-collapse border border-gray-300 text-black">
                    <thead>
                        <tr className="border-b-2 border-cyan-600">
                            <th className="text-lg ps-3 text-left py-2 border border-gray-300 font-bold" style={{ color: 'black', fontFamily: 'Consolas' }}>
                                Nombre
                            </th>
                            <th className="text-lg ps-3 text-left py-2 border border-gray-300 font-bold" style={{ color: 'black', fontFamily: 'Consolas' }}>
                                Latitud
                            </th>
                            <th className="text-lg ps-3 text-left py-2 border border-gray-300 font-bold" style={{ color: 'black', fontFamily: 'Consolas' }}>
                                Longitud
                            </th>
                            <th className="text-lg ps-3 text-left py-2 border border-gray-300 font-bold" style={{ color: 'black', fontFamily: 'Consolas' }}></th>
                        </tr>
                    </thead>
                    <tbody>
                        {stations.map((station) => (
                            <tr key={"cat-" + station.id} className="border-b border-gray-300">
                                <td className="ps-3 py-2 border border-gray-300" style={{ color: 'black', fontFamily: 'Consolas', fontWeight: 'bold' }}>
                                    {station.name}
                                </td>
                                <td className="ps-3 py-2 border border-gray-300" style={{ color: 'black', fontFamily: 'Consolas', fontWeight: 'bold' }}>
                                    {station.latitude}
                                </td>
                                <td className="ps-3 py-2 border border-gray-300" style={{ color: 'black', fontFamily: 'Consolas', fontWeight: 'bold' }}>
                                    {station.longitude}
                                </td>
                                <td className="ps-3 py-2 border border-gray-300 text-center">
                                    <a href={Routes.STATION.EDIT_PARAM(station.id)} className="me-2">
                                        <Button type="button" size="sm" className="bg-cyan-600 border-2 border-gray-400 text-black">
                                            Editar
                                        </Button>
                                    </a>
                                    <Button type="button" size="sm" color="red" className="border-2 border-red-900 text-black"
                                        onClick={() => { deleteStation(station.id!) }}>
                                        Eliminar
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </main>
        </>
    );
}

export default StationListPage;

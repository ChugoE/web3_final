import NavbarComponent from '../../components/NavbarComponent'
import { Routes } from '../../routes/CONSTANTS'

function HomePage() {
    return (
        <>
            <NavbarComponent />
            <main className="flex justify-center items-center min-h-screen bg-gray-800">
    <div className="bg-gray-900 text-white p-6 rounded-xl shadow-md text-center w-96">
        <h1 className="text-3xl font-bold py-5" style={{ fontFamily: 'Consolas' }}>
            Administrar
        </h1>
        <div className="flex justify-center gap-5">
            <a href={Routes.USER.LIST} className="bg-cyan-600 p-2 text-lg text-white font-bold 
                border-2 border-gray-400 rounded-md flex items-center justify-center" style={{ fontFamily: 'Consolas', fontWeight: 'bold' }}>
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-3-3h-4a3 3 0 00-3 3v2h5zM7 20h5v-2a3 3 0 00-3-3H4a3 3 0 00-3 3v2h5zM14 11a4 4 0 10-8 0 4 4 0 008 0zm10 0a4 4 0 10-8 0 4 4 0 008 0z"></path>
                </svg>
                Usuarios
            </a>
            <a href={Routes.STATION.LIST} className="bg-cyan-600 p-2 text-lg text-white font-bold 
                border-2 border-gray-400 rounded-md flex items-center justify-center" style={{ fontFamily: 'Consolas', fontWeight: 'bold' }}>
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 16v1a3 3 0 003 3h1a3 3 0 003-3v-1M5 13h14a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm7-5v1M7 9l2 2m2 2l2-2m2-2l2 2m-6-2a4 4 0 00-4-4 4 4 0 00-4 4h8zm8 0a4 4 0 00-4-4 4 4 0 00-4 4h8z"></path>
                </svg>
                Surtidores
            </a>
        </div>
    </div>
</main>


        </>
    );

}

export default HomePage
